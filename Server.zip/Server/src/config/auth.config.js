module.exports = {
    secret: "bcrypt-secret-key"
};
